window.onload = function() {
  var canvas        = document.getElementById("canvas");
  var context       = canvas.getContext("2d");
  var width         = canvas.width = window.innerWidth;
  var height        = canvas.height = window.innerHeight;
  var colors        = ['green','red','blue'];

  var circle    = TYPE6.Geometry.Circle.create( 0, 0, 40 );

  circle.draw( context, "#CC0000", null, null );

};
